import NextAuth from "next-auth"
import Providers from "next-auth/providers"
import { loginUser } from "lib/api"

export default NextAuth({
    // Configure one or more authentication providers
    providers: [
        Providers.Credentials({
            name: "My Provider",
            // credentials: {
            //     username: { label: "Email", type: "text", placeholder: "info@azarshiga.ir" },
            //     password: { label: "password", type: "password" }

            // },
            pages: {
                signIn: '/auth/login',
                // signOut: '/auth/signout',
                error: '/auth/login', // Error code passed in query string as ?error=
                // verifyRequest: '/auth/verify-request', // (used for check email message)
                newUser: null // If set, new users will be directed here on first sign in
            },
            async authorize(credentials) {
                const user = await loginUser(credentials.username, credentials.password);
                console.log(user);
                return user.user;
            }


        }),
        // ...add more providers here
    ],
    // A database is optional, but required to persist accounts in a database
    // database: process.env.DATABASE_URL,
    session: {
        // Use JSON Web Tokens for session instead of database sessions.
        // This option can be used with or without a database for users/accounts.
        // Note: `jwt` is automatically set to `true` if no database is specified.
        jwt: true,

        // Seconds - How long until an idle session expires and is no longer valid.
        maxAge: 2 * 60 * 60,

        // Seconds - Throttle how frequently to write to database to extend a session.
        // Use it to limit write operations. Set to 0 to always update the database.
        // Note: This option is ignored if using JSON Web Tokens
        updateAge: 24 * 60 * 60, // 24 hours
    },
    jwt: {
        // A secret to use for key generation - you should set this explicitly
        // Defaults to NextAuth.js secret if not explicitly specified.
        // This is used to generate the actual signingKey and produces a warning
        // message if not defined explicitly.
        // signingKey: 'INp8IvdIyeMcoGAgFGoA61DdBglwwSqnXJZkgz8PSnw',
        // You can generate a signing key using `jose newkey -s 512 -t oct -a HS512`
        // This gives you direct knowledge of the key used to sign the token so you can use it
        // to authenticate indirectly (eg. to a database driver)
        // signingKey: {"kty":"oct","kid":"Dl893BEV-iVE-x9EC52TDmlJUgGm9oZ99_ZL025Hc5Q","alg":"HS512","k":"K7QqRmJOKRK2qcCKV_pi9PSBv3XP0fpTu30TP8xn4w01xR3ZMZM38yL2DnTVPVw6e4yhdh0jtoah-i4c_pZagA"},
        // If you chose something other than the default algorithm for the signingKey (HS512)
        // you also need to configure the algorithm
        // verificationOptions: {
        //    algorithms: ['HS256']
        // },
        // Set to true to use encryption. Defaults to false (signing only).
        // encryption: true,
        // encryptionKey: "",
        // decryptionKey = encryptionKey,
        // decryptionOptions = {
        //    algorithms: ['A256GCM']
        // },
        // You can define your own encode/decode functions for signing and encryption
        // if you want to override the default behaviour.
        // async encode({ secret, token, maxAge }) {},
        // async decode({ secret, token, maxAge }) {},
    }
})